
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowRight,
  Clock,
  Newspaper,
} from 'lucide-react'

import { SectionHeading } from '@/components/common/SectionHeading'

const API_BASE_URL =
  'https://39production-api.39production.workers.dev'

interface News {
  id: number
  title: string
  slug?: string
  excerpt?: string
  content?: string
  category: string
  image_url?: string
  status: string
  published_at?: string
  created_at?: string
}

interface ApiResponse<T> {
  success: boolean
  data: T
  message?: string
}

function formatDate(date?: string) {
  if (!date) {
    return ''
  }

  const parsed = new Date(date)

  if (Number.isNaN(parsed.getTime())) {
    return date
  }

  return new Intl.DateTimeFormat('id-ID', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(parsed)
}

export function NewsSection() {
  const [news, setNews] = useState<News[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true

    async function loadNews() {
      try {
        const response = await fetch(
          `${API_BASE_URL}/api/news`,
          {
            cache: 'no-store',
          },
        )

        if (!response.ok) {
          throw new Error(
            'Failed to fetch news.',
          )
        }

        const result =
          (await response.json()) as ApiResponse<
            News[]
          >

        if (!mounted) {
          return
        }

        if (result.success) {
          setNews(
            (result.data ?? []).filter(
              (item) =>
                item.status === 'Published',
            ),
          )
        }
      } catch (error) {
        console.error(
          'Load news error:',
          error,
        )

        if (mounted) {
          setNews([])
        }
      } finally {
        if (mounted) {
          setLoading(false)
        }
      }
    }

    loadNews()

    return () => {
      mounted = false
    }
  }, [])

  if (!loading && news.length === 0) {
    return null
  }

  return (
    <section className="relative py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <SectionHeading
          label="Latest Updates"
          title="News & Announcements"
          description="Stay up to date with the latest updates from 39Production."
        />

        {loading ? (
          <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((item) => (
              <div
                key={item}
                className="h-64 animate-pulse rounded-2xl border border-border-default bg-bg-surface"
              />
            ))}
          </div>
        ) : (
          <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {news.slice(0, 6).map((item) => (
              <Link
                key={item.id}
                to="/news"
                className="group overflow-hidden rounded-2xl border border-border-default bg-bg-surface transition-all duration-300 hover:-translate-y-1 hover:border-brand-primary/30"
              >
                <div className="relative h-44 overflow-hidden bg-bg-elevated">
                  {item.image_url ? (
                    <img
                      src={item.image_url}
                      alt={item.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center">
                      <Newspaper className="h-12 w-12 text-text-muted/30" />
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                </div>

                <div className="p-6">
                  <div className="flex items-center gap-3">
                    <span className="rounded-full bg-bg-elevated px-3 py-1 text-xs font-medium text-text-secondary">
                      {item.category}
                    </span>

                    {(item.published_at ||
                      item.created_at) && (
                        <span className="flex items-center gap-1 text-xs text-text-muted">
                          <Clock className="h-3 w-3" />

                          {formatDate(
                            item.published_at ??
                            item.created_at,
                          )}
                        </span>
                      )}
                  </div>

                  <h3 className="mt-4 line-clamp-2 text-lg font-semibold text-text-primary transition-colors group-hover:text-brand-primary">
                    {item.title}
                  </h3>

                  {item.excerpt && (
                    <p className="mt-2 line-clamp-3 text-sm leading-6 text-text-muted">
                      {item.excerpt}
                    </p>
                  )}

                  <div className="mt-5 flex items-center gap-2 text-sm font-medium text-brand-primary">
                    Read More
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

        {!loading && news.length > 6 && (
          <div className="mt-12 text-center">
            <Link
              to="/news"
              className="inline-flex items-center gap-2 rounded-lg border border-border-default px-6 py-3 text-sm font-semibold text-text-primary transition-all hover:border-brand-primary/50 hover:text-brand-primary"
            >
              All News
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        )}
      </div>
    </section>
  )
}
